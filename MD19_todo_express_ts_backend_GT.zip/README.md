# TODO List Express Backend part
To start developing run `npm install` and then `npm run start:nodemon`

### `MangoDB` data not included
